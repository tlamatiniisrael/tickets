<div class="ui small modal" id="delete">
    <div class="header">Borrar usuario</div>
    <div class="content">
        <p>¿Estas seguro que deseas borrar al usuario?</p>
    </div>
    <div class="actions">
        <div class="ui right labeled icon button button-cancel">No <i class="remove icon"></i> </div>
        <div class="ui right labeled icon button button-accept">Si <i class="checkmark icon"></i> </div>
    </div>
</div>
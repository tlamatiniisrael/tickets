<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<footer>
		<script type="text/javascript">
			var base_url = '<?= base_url();?>';
		</script>
		<script type="text/javascript" src="<?= base_url('assets/js/plugins/jquery.generateFile.js')?>"></script>
		<script type="text/javascript" src="<?= base_url('assets/js/plugins/datatables.min.js')?>"></script>
		<script type="text/javascript" src="<?= base_url('assets/js/plugins/jquery.validate.min.js')?>"></script>
		<script type="text/javascript" src="<?= base_url('assets/semantic/dist/semantic.min.js')?>"></script>	
		<script type="text/javascript" src="<?= base_url('assets/js/utilerias.js')?>"></script>
	</footer>